Video Catcher All Formats v2.4.0

Playback-first detection: waits for 8 seconds of playback before promoting a file, de-prioritizes short ad-like segments and ad-marked players. This heuristic cannot guarantee ad exclusion. HLS master playlists show variants with highest listed first; actual qualities depend on source. Original audio preserved for integrated streams. No automatic transcoding, DRM unlocking, or separate audio merging.


## v2.5 improvements

- Preferred quality saved locally (highest / 1080p / 720p / 480p, nearest lower available).
- Automatically preselects matching detected HLS variants; never manufactures qualities.
- Original-audio preference available; audio merging/transcoding remains unsupported.
- See [REFERENCE_FEATURE_AUDIT.md](REFERENCE_FEATURE_AUDIT.md) for a feature-by-feature architecture review.

## v2.6 changes
- Tracks stable player element IDs to mark earlier media as superseded once a later confirmed video starts in the same player. This reduces (but cannot eliminate) pre-roll ad false positives.
- Adds an optional local history panel for successfully started direct downloads (100 most recent).
- Preserves previous source filters, title extraction, HLS variant selector, preferred quality and original audio handling.
- **Not a guarantee of ad removal:** the user can still review all sources, and same-player transitions may be ambiguous.


## v2.7 changes
- **Mark Main Video / Not Main (Ad)** controls let you correct false ad/main detection; choices persist for the current tab session.
- HLS master playlists now expose separately signaled audio renditions where available, with an option to save the chosen audio stream **as a separate original file**. They are NOT muxed into video: do not mistake two files for a playable combined video.
- Existing quality and original-audio preferences and source history remain.
- DRM, automatic ad skipping, DASH transcoding, and reliable universal audio/video muxing are not implemented. Some cross-origin media sites cannot be downloaded from a browser extension.

## v2.8 additions
- Experimental unencrypted **static MPEG-DASH SegmentList** support, including selectable video qualities and optional separate audio download. Not all MPDs use SegmentList; SegmentTemplate, DRM and dynamic/live manifests remain unsupported.
- Includes [MUXING.md](MUXING.md) with commands to combine compatible video/audio tracks locally using FFmpeg **without re-encoding**. Automatic one-click in-browser muxing is not implemented.
- Source video-ad detection remains heuristic; false positives may need the manual Main Video / Not Main controls.

## v2.9 additions
- Recognizes a subset of unencrypted static MPEG-DASH SegmentTemplate manifests using fixed segment duration and `$Number$` templates; multi-period, timelines, live manifests and DRM are unsupported.
- Uses detected page/video title for HLS and DASH file naming.
- Automatically preselects a compatible original audio rendition, when the original-audio preference is enabled. Audio and video still download separately and require muxing.
- Includes a local optional mux helper script that copies existing streams with FFmpeg without transcoding.
- Note: these are experimental source features; end-to-end browser validation remains necessary.
